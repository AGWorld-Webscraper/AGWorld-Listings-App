﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace AGWorld_Listings_App
{
    internal class ListingEntry
    {
        public enum Priority { Disregarded, Low, High }
        [JsonInclude]
        private Listing_Info _listing;
        [JsonInclude]
        private Priority _priority;
        [JsonInclude]
        private List<Note> _notes;

        public ListingEntry(Listing_Info Listing)
        {
            _listing = Listing;
            _priority = Priority.Low;
            _notes = new List<Note>();
        }

        [JsonConstructor]
        public ListingEntry(Listing_Info _listing, Priority _priority, List<Note> _notes) : this(_listing)
        {
            this._priority = _priority;
            this._notes = _notes;
        }   

        public String getAddress() { return _listing.getName(); }


        public String[] toDataGrideRow()
        {
            String[] listingArr = _listing.toDataGridRow();
            String[] returnArr = new string[listingArr.Length+1];
            returnArr[0] = _priority.ToString();
            for (int i = 0; i < listingArr.Length; i++)
            {
                returnArr[i+1] = listingArr[i];
            }
            return returnArr;
        }

        public void fromDataGridRow(DataGridViewRow dvr)
        {
            _priority = Enum.Parse<Priority>(dvr.Cells[0].Value.ToString());

        }

        public void updateNotes(ListingEntry Other)
        {
            this._notes = combineNotes(this, Other);
        }

        public void editNote(String content, String thisAuthor, String thisContact)
        {
            if (!(_notes[0].Equals(thisAuthor)))
            {
                _notes.Insert(0, new Note(content));
            } else
            {
                _notes[0].setContent(content);
            }
        }

        public static List<Note> combineNotes(ListingEntry a, ListingEntry b)
        {
            List<Note> _notes = a._notes;
            List<Note> OtherNotes = b._notes;
            foreach (Note Note in OtherNotes)
            {
                if (_notes.Contains(Note))
                {
                    int index = _notes.IndexOf(Note);
                    _notes[index] = Note;
                }
                else
                {
                    Note mainNote = _notes[0];
                    _notes.Remove(mainNote);
                    _notes.Add(Note);
                    _notes.Sort();
                    _notes.Insert(0, mainNote);
                }
            }
            return _notes;
        }

        public static ListingEntry operator +(ListingEntry a, ListingEntry b)
        {
            a._notes = combineNotes(a, b);
            return a;
        }
    }
}
