﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace AGWorld_Listings_App
{
    internal class Note : IComparable<Note>
    {
        public static String defaultAuthor, defaultContact;

        [JsonInclude]
        private String _author;
        [JsonInclude]
        private String _contact;
        [JsonInclude]
        private String _content;

        [JsonConstructor]
        public Note(String _author, String _contact, String _content)
        {
            this._author = _author;
            this._contact = _contact;
            this._content = _content;
        }

        public Note(String content)
        {
            _author = defaultAuthor;
            _contact = defaultContact;
            this._content = content;
        }

        public void setContent(String c) { _content = c; }

        public static void setDefaultContact(String Author, String contact)
        {
            defaultAuthor = Author;
            defaultContact = contact;
        }

        public static bool operator ==(Note left, Note right)
        {
            return left._author == right._author;
        }
        public static bool operator !=(Note left, Note right)
        {
            return left._author != right._author;
        }

        public override bool Equals(object? obj)
        {
            if(obj is Note)
            {
                return (Note)obj == this;
            }
            if(obj is String)
            {
                return (String)obj == this._author;
            }
            return false;
        }

        public int CompareTo(Note? other)
        {
            return _author.CompareTo(other?._author);
        }
    }
}
