﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace AGWorld_Listings_App
{
    internal class Listing_Info
    {
        [JsonInclude]
        private String _address;
        [JsonInclude]
        private Firm _firm;
        [JsonInclude]
        private String _listingLink;
        [JsonInclude]
        private DateTime _listingDate;
        [JsonInclude]
        private DateTime _auctionDay;

        [JsonConstructor]
        public Listing_Info(string _address, Firm _firm, string _listingLink, DateTime _listingDate, DateTime _auctionDay)
        {
            this._address = _address;
            this._firm = _firm;
            this._listingLink = _listingLink;
            this._listingDate = _listingDate;
            this._auctionDay = _auctionDay;
        }

        public String[] toDataGridRow()
        {
            return new String[]
            {
                _address, _firm.getName(), _listingDate.ToString(), _auctionDay.ToString()
            };
        }

        /*
        public int numTimesListing() { return _listingDates.Length; }
        public bool isBuyable() { return _listingDates.Length == 3; }
        */
        public bool stillValid() { return _auctionDay.CompareTo(DateTime.Today) < 0; }
        public String getName() { return _address; }

    }
}
