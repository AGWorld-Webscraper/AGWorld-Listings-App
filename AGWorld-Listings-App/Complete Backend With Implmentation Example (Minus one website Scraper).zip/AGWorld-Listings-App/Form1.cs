namespace AGWorld_Listings_App
{
    public partial class Form1 : Form
    {
        Listings_Manager manager;
        public Form1()
        {
            //example table :)
            InitializeComponent();
            String[] row = new String[] { "Priority", "Address", "Firm", "FirstListing", "AuctionDate" };
            foreach (String s in row)
            {
                dataGridView1.Columns.Add(s, s);
            }
            manager = new Listings_Manager();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //example button to force load up pages
        private void button1_Click(object sender, EventArgs e)
        {
            manager.loadWebsites();
            dataGridView1 = manager.setDataGridView(dataGridView1);

        }


        //example saving to a folder
        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog opd = new OpenFileDialog();
            opd.Multiselect = true;
            opd.Filter = "JSON files (*.json)|*.json|Folders|*.folder";

            DialogResult result = opd.ShowDialog();
            if (result == DialogResult.OK)
            {
                //file
                if (opd.FileName.Contains(".json"))
                {
                    manager.Save(opd.FileName);
                } else//folder
                {
                    manager.Save(opd.FileName + "/Listings.json");
                }
            }

        }

        //example loading from a file
        private void button3_Click(object sender, EventArgs e)
        {
            List<String> invalidFiles = new List<string>();
            OpenFileDialog opd = new OpenFileDialog();
            DialogResult result = opd.ShowDialog();
            if (result == DialogResult.OK)
            {
                String[] FileNames = opd.FileNames;
                foreach(string f in FileNames)
                {
                    manager.Load(f);
                    
                }
                dataGridView1 = manager.setDataGridView(dataGridView1);
            }
        }
    }
}
